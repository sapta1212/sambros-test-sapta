<?php
// exec("./New_Tsel version", $retVal);	// Check appl version | command
//exec("./New_Tsel_Poin_Processing db_init 127.0.0.1 5432 postgres postgres NEWTELKOMSELPOINDEV", $retVal); // Initialize database | command<space>db ip<space>db port<space>db username<space>db password<space>db name
// exec("./New_Tsel_Poin_Processing enc_api_key 86342649958289995446", $retVal); // Encrypt api key | command<space>api key
// exec("./New_Tsel transaction_query all none 20190501 20190531 3 100", $retVal); // transaction_query | command<space>select query<space>ext condition query<space>date from (YYYYMMDD)<space>date to (YYYYMMDD)<space>data interval<space>delay ms
// exec("./New_Tsel transaction_query all batch_number=6 20190501 20190531 3 100", $retVal); // transaction_query | command<space>select query<space>ext condition query<space>date from (YYYYMMDD)<space>date to (YYYYMMDD)<space>data interval<space>delay ms
//exec("./New_Tsel_Poin_Processing transaction_query all batch_number=6andamount=25000 20190501 20190531 3 100", $retVal); // transaction_query | command<space>select query<space>ext condition query<space>date from (YYYYMMDD)<space>date to (YYYYMMDD)<space>data interval<space>delay ms
print_r($retVal);
?>